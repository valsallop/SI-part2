import org.apache.spark._
import org.apache.spark.SparkContext._
import org.apache.spark.streaming._
import org.apache.spark.streaming.twitter._
import org.apache.spark.streaming.StreamingContext._
import TutorialHelper._

object Tutorial {
  def main(args: Array[String]) {
    
    // Checkpoint directory
    val checkpointDir = TutorialHelper.getCheckpointDirectory()

    // Configure Twitter credentials
    val apiKey = "JMVtLK81RWRIFic2VukMnv09s"
    val apiSecret = "ofJLHj5pKErl8homxn2ZhhGrrmqJVvgXszhJUxerIB8vk40KWU"
    val accessToken = "3043438018-T7MxRruTuwulTQzHpPj8Uh9fm3LHVu8UWGDBrjV"
    val accessTokenSecret = "Y8bNzhByVItLId5LBQ78q1vK83jUIdAGwqHUSAQZLPTtp"
    TutorialHelper.configureTwitterCredentials(apiKey, apiSecret, accessToken, accessTokenSecret)

    // Your code goes here
	val ssc = new StreamingContext(new SparkConf(), Seconds(1))
    	val tweets = TwitterUtils.createStream(ssc, None)
    //val statuses = tweets.map(status => status.getText())

    println("------------Sample JSON Tweets-------")
    
    //Comprobamos que los tweets esten relacionados con peliculas
    //val statusesFilm = tweets.filter(status => status.getText.toLowerCase.contains("film"))
    
    // Lista de generos clave 

    val gen = Array("action", "adventure", "animation", "children", "comedy", "crime", "documentary", "drama", "fantasy", "film-noir", "horror", "musical", "mystery", "romance", "sci-fi", "thriller", "war", "western")

    // Se filtran los generos a los tweets que son peliculas

    val statusesFilter = tweets.filter { status =>

      gen.exists { word => status.getText.toLowerCase.contains(word) }

    }
    
    //statusesFilter.print()
    
    //Almacenamos los tweets que son peliculas en el HDFS
    var oldCount=0L
    val info="AVISO:INCREMENTO DE TUITS RELACIONADOS SUPERIOR AL 30%"
    statusesFilter.foreachRDD((rdd, time) => {
      val count = rdd.count()
      if (count > 0) {
        val outputRDD = rdd.repartition(1)
        outputRDD.saveAsTextFile("hdfs://localhost:9000/tweetsfilter/tweets_" + time.milliseconds.toString)
      }
      if(count*0.7 > oldCount){
	println(info)
      }
      oldCount=count
    })

    
    //statuses.print()
    ssc.checkpoint(checkpointDir)

    ssc.start()
    ssc.awaitTermination()

  }
}
